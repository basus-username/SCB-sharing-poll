YouVote 2.0 — Vercel bundle
Snapshot date: 2026-08-10

This is a fresh, separate build of YouVote — its own GitHub repo and its
own Firebase project (see docs/SETUP-GUIDE.md Part 1), fully isolated
from the original app's live poll data. Treat it as a real candidate to
launch to your friends if it works out, not just a throwaway test — but
it's still deliberately kept separate so trying it out can't affect the
original in any way. The app files are the current, real feature set —
this isn't a stripped-down demo.

Current feature set (all of the below is included):
- Realtime group polls (Firestore-backed) — single-choice or
  multiple-choice, toggle any time
- Text options with a name, notes, and any number of links; links can be
  auto-searched (pastes from clipboard or auto-triggers on paste) to fill
  in a display name, including special handling so Google Maps links
  resolve reliably without hitting Google's bot-block wall
- Date options via an in-app calendar picker (multi-select days)
- Tap an option's row to vote, tap only its small arrow to see details —
  kept deliberately separate so browsing details never accidentally
  casts a vote
- Neutral, unbiased progress bars — no option is ever visually
  highlighted as "winning"
- Swipe-left to delete an option (or a poll from the home list), tuned
  for an easy one-thumb swipe
- Bulk-select mode to delete several options at once
- Per-visit local Undo/Redo (vote, add, edit, delete) plus a separate
  one-shot Undo for deleting a whole poll
- "Copy results as image" — exports the current standings as a PNG,
  shares directly through the OS share sheet where supported
- Optional auto-lock time for a poll (stops new options being added,
  checked lazily whenever anyone has the poll open)
- No login — a name is set once per device and remembered; includes a
  "claim votes from a previous name" tool to fix the one real gap in that
  approach (clearing site data mints a new identity, orphaning old votes
  under the old one)
- "Share to YouVote" — registered as an Android share-sheet target, so a
  link seen in a WhatsApp chat can be shared straight into the right
  poll's Add-option form in two taps, pre-searched, instead of manually
  copy-pasting

WHAT'S INSIDE:
- index.html, manifest.json, sw.js, icons/, api/resolve-link.js
  -> the actual app files, ready to upload to a NEW GitHub repo -> Vercel
  -> index.html has PLACEHOLDER Firebase config values (search
     "REPLACE_WITH_YOUR") — it will not run until you create your own
     Firebase project and paste in real values. This is intentional, see
     docs/SETUP-GUIDE.md Part 1–2.
  -> app name is set to "YouVote 2.0" (in manifest.json and in-app) so
     it's visually distinguishable from the original YouVote if both end
     up installed on the same phone.
- docs/MASTER-PROMPT.md
  -> paste into a fresh Claude chat to rebuild this app from scratch if
     ever needed — a precise spec, not a casual description
- docs/SETUP-GUIDE.md
  -> step-by-step click-by-click setup instructions: new Firebase
     project, GitHub, Vercel, PWA install, troubleshooting

Keep naming future snapshots the same way so they sort and search
easily: youvote-2.0_VERCEL_YYYY-MM-DD.zip
