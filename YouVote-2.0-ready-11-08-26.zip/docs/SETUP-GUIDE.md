YouVote 2.0 — Setup & Installation Guide
======================================================

This is a from-scratch, click-by-click guide for getting this build of
YouVote from a folder of files on your phone to a live, installable app
— no computer needed, no prior experience assumed. Written for a
brand-new, fully separate Firebase project, so this build stays
completely isolated from the original YouVote's live poll data — useful
whether you're evaluating it or planning to launch it to your friends in
place of the original.

Total files you should have before starting:
```
index.html
manifest.json
sw.js
icons/
  icon-192.png
  icon-512.png
  apple-touch-icon.png
api/
  resolve-link.js
```

PART 1 — Create a new, separate Firebase project
----------------------------------------------------

This is the part that makes this an isolated project of its own instead
of a second window into your existing data. Takes about 5 minutes.

1. On your phone, go to **console.firebase.google.com**
2. Sign in with any Google account (can be the same one your real
   YouVote project uses — a Google account can own many separate
   Firebase projects, they don't share data with each other)
3. Tap **Add project** (or **Create a project**)
4. Give it a name, e.g. `youvote-2-0` — Firebase will generate a unique
   project ID from this, which is fine
5. You can disable Google Analytics for this project (toggle it off) —
   not needed for YouVote
6. Tap **Create project**, wait for it to finish, then **Continue**

**Turn on Firestore (the database):**

7. In the left sidebar, tap **Build → Firestore Database**
8. Tap **Create database**
9. Choose a location close to you (e.g. `asia-southeast1` for Malaysia)
   — this can't be changed later, but it doesn't need to match your real
   project's location
10. Choose **Start in production mode** (not test mode — test mode
    quietly locks the whole database down again after 30 days, which is
    a confusing bug to hit later; we'll set explicit rules in step 14
    instead)
11. Tap **Create**

**Register a web app to get your config values:**

12. In the left sidebar, tap the ⚙️ gear icon next to **Project
    Overview** → **Project settings**
13. Scroll to **Your apps** → tap the **</>** (web) icon
14. Give it a nickname, e.g. `youvote-2-0-web` → **Register app** (skip
    the "Add Firebase SDK" code snippet step, you don't need it — you'll
    copy the config values in Part 2 instead)
15. You'll see a `firebaseConfig` object with 6 values (`apiKey`,
    `authDomain`, `projectId`, `storageBucket`, `messagingSenderId`,
    `appId`) — keep this screen open or copy these somewhere safe, you'll
    need them in Part 2

**Set the database rules (do this now, not later):**

16. Back in **Firestore Database**, tap the **Rules** tab
17. Replace everything in the box with:
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /polls/{pollId} {
      allow read, write: if true;
      match /options/{optionId} {
        allow read, write: if true;
      }
    }
  }
}
```
18. Tap **Publish**

(This app has no login system, so there's no user identity to check
rules against — these rules just scope access to this app's own
`polls`/`options` collections instead of leaving the entire project
open, and avoid the 30-day test-mode expiry trap.)

PART 2 — Paste your config into index.html
-----------------------------------------------

1. Open `index.html` from this bundle in any text/file editor app on your
   phone
2. Find this block near the top of the `<script type="module">` section
   (search for `REPLACE_WITH_YOUR`):
```js
const firebaseConfig = {
  apiKey: "REPLACE_WITH_YOUR_API_KEY",
  authDomain: "REPLACE_WITH_YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "REPLACE_WITH_YOUR_PROJECT_ID",
  storageBucket: "REPLACE_WITH_YOUR_PROJECT_ID.firebasestorage.app",
  messagingSenderId: "REPLACE_WITH_YOUR_SENDER_ID",
  appId: "REPLACE_WITH_YOUR_APP_ID"
};
```
3. Replace all 6 placeholder values with the real ones from Part 1, step
   15 — keep the quote marks, just swap what's inside them
4. Save the file

If you skip this step, the app will fail to load poll data (it'll just
sit there, or show a Firebase error in the toast) rather than silently
connecting anywhere — that's intentional, so a forgotten step is obvious
immediately instead of causing confusion later.

PART 3 — Upload the code to GitHub (a NEW repo, not your existing one)
----------------------------------------------------------------------------

1. Go to **github.com** → sign in
2. Tap the **+** icon (top right) → **New repository**
3. Give it a name, e.g. `youvote-2-0` (different from your original repo's
   name, so they're easy to tell apart in your GitHub list) → choose
   Public or Private, either works → **Create repository**
4. On the new repo's page, tap **Add file → Upload files**
5. Upload `index.html`, `manifest.json`, `sw.js`, and the whole `icons`
   folder together
6. Scroll down → **Commit changes**

**Now the tricky part — the `api` folder.** GitHub's drag-and-drop
uploader flattens folders, so you can't upload `resolve-link.js` inside
an `api` folder that way. Instead:

7. Back on the repo's main page, tap **Add file → Create new file**
8. In the filename box, type: `api/resolve-link.js` — typing the `/`
   automatically creates the `api` folder for you
9. Open `resolve-link.js` from this bundle in any text/file viewer app,
   select all the text, copy it
10. Paste the full contents into GitHub's editor
11. Scroll down → **Commit changes**

Your repo should now show `index.html`, `manifest.json`, `sw.js`, an
`icons` folder, and an `api` folder containing `resolve-link.js`.

**Also upload the docs, for your own future reference:**

12. **Add file → Create new file** → type `docs/MASTER-PROMPT.md` →
    paste its contents → **Commit changes**
13. Repeat for `docs/SETUP-GUIDE.md` and `docs/README.txt`

PART 4 — Deploy on Vercel
----------------------------

1. Go to **vercel.com** → **Sign Up** → **Continue with GitHub** (this
   links the accounts automatically) — or **Log In** if you already have
   an account from your original YouVote project (one Vercel account can host
   many separate projects, same as Firebase)
2. Authorize Vercel to access your GitHub account, if asked
3. On your Vercel dashboard, tap **Add New → Project**
4. Find your new repo (e.g. `youvote-2-0`) in the list → tap **Import**
5. Leave all build settings as default → tap **Deploy**
6. Wait for the first deploy to finish (usually under a minute)
7. Vercel gives you a live URL like `youvote-2-0.vercel.app` — open it
   and try creating a test poll to confirm it saves and loads

No environment variables to set for this app — unlike an AI-scanning
feature, `resolve-link.js` needs no API key, so Part 4 ends here.

PART 5 — Install it as an app on your phone
-----------------------------------------------

**Android (Chrome):**
1. Open your Vercel URL in Chrome
2. Tap the **⋮** menu (top right)
3. Tap **Add to Home Screen** (or **Install app**)
4. Confirm

Since the app's `name`/`short_name` in `manifest.json` are set to
"YouVote 2.0" for this bundle, it'll show a different label under the
icon than the original YouVote — easy to tell apart on your home screen.

**iPhone (Safari):**
1. Open your Vercel URL in Safari
2. Tap the **Share** button (square with an arrow, bottom of screen)
3. Scroll down → tap **Add to Home Screen**
4. Tap **Add**

**About "Share to YouVote" from WhatsApp:** this only works on Android
Chrome (iOS Safari doesn't support the underlying Web Share Target API).
If you already had a version of this app installed on this phone before
today, Android may not notice the new share capability right away —
remove it from your home screen and re-add it (repeat the 4 steps above)
to force Chrome to pick it up immediately.

PART 6 — Making future changes
----------------------------------

Whenever you want to update this test app later:

1. Edit the file on GitHub directly (open the file → pencil/edit icon →
   make changes → **Commit changes**), or upload a replacement version
   via **Add file → Upload files**
2. Vercel automatically detects the GitHub change and redeploys within
   about a minute — no manual redeploy needed, and no environment
   variables to worry about re-applying
3. On your phone, the installed app should pick up the change next time
   you open it with a network connection, since the service worker
   always checks for the latest version first

TROUBLESHOOTING QUICK REFERENCE
-----------------------------------

| Symptom | Likely cause |
|---|---|
| Polls won't save / load, toast shows a Firebase error | `firebaseConfig` in `index.html` still has `REPLACE_WITH_YOUR_*` placeholders, or one value was mistyped — recheck against Part 1 step 15 |
| "Missing or insufficient permissions" error | Firestore rules weren't published, or were left in default test-mode and have since expired (30-day window) — recheck Part 1 steps 16–18 |
| Fix doesn't seem to apply after a redeploy | Old symptom from a cache-first service worker — this app's `sw.js` is network-first on purpose, so this shouldn't recur; if it does, force-close and reopen the installed app |
| `api/resolve-link.js` not working (link search never finds a name) | Check it's actually inside an `api` folder in GitHub, not sitting at the repo root as a flat file |
| A Google Maps link never resolves | Expected for some short/unusual links — the app deliberately avoids scraping Maps' page content (Google blocks that with a captcha wall), so it only works when the pasted link already contains the place name, or is a short link it can redirect-resolve. Type the name in manually if it fails. |
| "YouVote" doesn't appear in Android's Share sheet from WhatsApp | Reinstall the home-screen shortcut (Part 5) so Chrome re-reads the updated manifest — it only checks periodically otherwise |
| iPhone friend says YouVote isn't in their Share sheet | Expected — iOS Safari doesn't support share targets yet. They can still open the poll link normally and add options by hand |
