Master Rebuild Prompt — YouVote (v1)
=====================================

Paste everything below into a fresh chat to rebuild this app exactly as-is.
Do not change the interaction model, data model, or visual language —
treat this as a precise spec, not a starting point for redesign. This is
the first formalized master prompt for YouVote, written after several
rounds of real-world testing and fixes; it captures the app's current
shipped behavior, including the reasoning behind non-obvious choices so a
rebuild doesn't accidentally regress them.

PROMPT STARTS HERE
------------------

You are an expert front-end engineer and product designer. Build me a
self-contained mobile-first PWA (HTML + inline CSS + inline JS, no build
step, no external JS frameworks) called "YouVote" — a group poll voting
app meant to beat WhatsApp's native polls on link-rich options (places,
dates, posts) and low-friction voting. It must deploy on Vercel via a
GitHub-connected project and use Firebase Firestore as the real-time
backend (no login system — see §2). Deliver these exact files:

- `index.html` — everything (HTML/CSS/JS) in one file
- `manifest.json` — PWA manifest, including a Web Share Target registration
  (§9)
- `sw.js` — service worker, **network-first**, not cache-first (§10 — this
  matters, see the reasoning there)
- `icons/icon-192.png`, `icons/icon-512.png`, `icons/apple-touch-icon.png`
  — app icons (§8)
- `api/resolve-link.js` — Vercel serverless function that turns a pasted
  link (Google Maps, articles, etc.) into a clean option name (§6)

1. DATA MODEL (Firestore)
--------------------------

```
polls/{pollId}
  title: string
  subtitle: string (optional)
  multiChoice: boolean          // single-choice vs multi-choice voting
  closed: boolean                // true = no new options can be added; voting stays open
  closeAt: ISO string | null    // optional auto-lock time (§5)
  createdAt: server timestamp

polls/{pollId}/options/{optionId}
  name: string
  notes: string
  link: string | null            // first/primary link, kept for backward compatibility
  links: string[]                 // all links (option can have multiple)
  isDate: boolean
  dateISO: string | null          // set when isDate is true
  votes: { [voterId]: { name: string, initials: string } }
  createdAt: server timestamp
```

`pollId` is generated from the poll title, not a random string (§2.1) —
share links should read like the poll, not an opaque code.

Voting is just adding/removing your own key under `votes` on an option
doc. Single-choice polls remove your key from every *other* option in the
same poll before adding it to the chosen one (client-side enforced, not a
Firestore rule — see §11 for the one exception, identity merging).

2. VOTER IDENTITY (no login, device-local)
--------------------------------------------

No accounts. On first visit to any poll, prompt for a display name; store
`{id: <random>, name, initials}` in `localStorage` under keys
`poll_voter_id` / `poll_voter`. This identity is reused across every poll
on this device thereafter. `initials` is derived from the name (first
letter of up to 2 words, uppercased). Assign each voter a consistent
color across the whole device via a small fixed palette, keyed by
`voter.id` (a simple hash-to-index is fine).

**Known limitation, and the mitigation to build in:** clearing browser
site data wipes localStorage, so the device gets a brand-new random voter
id — the person effectively becomes a new person to every poll, with
their old votes orphaned under the old id. Two things blunt this:

- **Quick rejoin**: if the device has no saved identity yet, the name
  prompt scans the current poll's existing votes for distinct names and
  offers them as tappable "is this you?" chips above the text input.
  Tapping one adopts that exact voter id (merging future votes into it)
  instead of minting a new one.
- **Retroactive claim**: the poll's ⋯ menu has "Claim votes from a
  previous name" — lists every other voter id/name found in the poll's
  options, lets the user pick one, confirms, then for each option: moves
  `votes[oldId]` to `votes[currentId]` and deletes the old key. For
  single-choice polls, if the current identity already has a vote
  somewhere, don't overwrite it — just drop the stale duplicate instead of
  moving it (a single-choice voter can't validly hold two picks).

2.1 — Poll ID generation:

```js
function slugify(s){
  return (s || '')
    .normalize('NFKD').replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40);
}
function genPollId(title){
  const slug = slugify(title);
  return slug ? `${slug}-${genId(5)}` : genId(8); // genId = random base36 string
}
```

This makes share links read like `yourapp.vercel.app/?poll=weekend-hike-a8f3k`
instead of an opaque random string — no custom domain or DNS work needed.

3. HOME VIEW
-------------

Brand header, hero copy, a "Create a poll" input + button, and a list of
this device's recently-visited polls (from `localStorage`, most recent
first, swipe-left to remove from the list — this only forgets it locally,
it does not delete the poll itself). Each recent-poll row swipes exactly
like poll options do (§7).

4. POLL VIEW — LAYOUT
------------------------

**Sticky title bar — structural note that matters:** the poll title must
be its own top-level `position:sticky; top:0` element, a **direct
sibling** of the rest of the poll header (subtitle/meta/chip row), *not*
nested inside a short wrapper div containing that other content. A sticky
element can never stay stuck past the bottom edge of its own containing
block — nest it inside a ~150px-tall header div and it will un-stick and
scroll away after only ~150px of scrolling, which reads as broken. Hoist
it out so its containing block spans the whole poll view.

Below the sticky title: subtitle (if set, pulled visually close to the
title — small negative top margin — with a clearer gap before the row
below it, so title+subtitle read as a pair distinct from the stats below),
then a meta row (`Open`/`Options locked` pill · N options · optional
auto-lock time), then a chip row: **Single/Multiple** toggle, **Share**
(copies the poll URL), and a **⋯** menu.

⋯ menu items:
- 📋 Copy results — renders a results image via `<canvas>` (name, vote
  count, percentage, one bar per option) and shares/copies it as a PNG
  (§4.1)
- 🙋 Claim votes from a previous name (§2)
- ☑️ Select options to delete (bulk delete mode)
- 🔒/↺ Lock/unlock options (voting stays open either way; this only
  gates adding *new* options)
- ⏰ Auto-lock options at a set time (datetime picker; a `setInterval`
  polls every 30s client-side and flips `closed:true` once `closeAt` has
  passed — there's no server cron, so this is lazily evaluated by
  whoever's viewport happens to be open)

4.1 — Fairness requirement for both the live bars and the results image:
**every option renders with the same neutral bar color, regardless of
vote count.** Do not highlight a "leading" option in gold or any other
distinct color — that reads as bias in a group-decision tool, which
defeats the point.

5. ADD-OPTION FLOW
--------------------

Two tabs: **Text option** and **Pick dates**.

**Text option tab — exact field order and behavior:**
1. **Name** (plain text input)
2. **Paste a link** — bold white label, then a smaller, non-bold, muted
   subtitle line: "Optional — eg: Maps, XHS, IG, etc". Input row: link
   field, a small subtle ✕ clear button, a **Search** button (reads
   clipboard if permitted, else uses whatever's already typed, then calls
   `/api/resolve-link`). Status line below shows "Reading link…" then
   either "Found: <name>" or a specific, actionable error (§6) — never a
   silent failure.
   Below that, an "＋ Add another link" button that appends more link
   rows (options can carry more than one link). Give this extra-links
   block **visible top margin** separating it from the first link row —
   don't let it sit flush against the row above, that reads as cluttered.
3. **Notes** — same bold-label-then-muted-subtitle pattern ("Optional").

Every input's placeholder text should render slightly smaller than typed
text (`::placeholder{font-size:...}` a couple px under the field's own
font-size) — it's a hint, not content, and shouldn't visually compete with
what the user types.

**Draft persistence within a visit:** whatever's typed into Name/Link
should survive a re-render of the poll view (e.g. a Firestore snapshot
update arriving while the user is mid-type) — keep them in a small
`draftName`/`draftLink` state object outside the render function, updated
on every `input` event and after any programmatic fill (like a successful
link resolve), and read back into the form's `value=` on each render. This
also happens to be exactly what makes an incoming shared link (§9)
robust against a race with an early snapshot update.

**Pick dates tab:** a month calendar, tap days to multi-select, "Add N
dates" batch-adds them all as date-type options in one action.

6. LINK RESOLUTION — `/api/resolve-link.js`
-----------------------------------------------

Given a pasted URL, return `{ name, resolvedUrl }` or `{ error: string }`
(always a specific, human-readable error — never a bare status code).

**Google Maps gets special handling, and must never fetch the actual maps
content page.** Google actively blocks automated/datacenter-IP fetches of
maps.google.com content pages with a "detected unusual traffic" captcha
wall — any text scraped from that wall is garbage and must never reach
the user. The fix: Maps share links almost always already carry the place
name directly in the URL path (`/maps/place/Some+Place+Name/...`), so
parse it straight out of the URL string with **zero network calls** for
the common case:

```js
function extractPlaceNameFromMapsUrl(u) {
  const placeMatch = u.match(/\/maps\/place\/([^/@]+)/);
  if (placeMatch) return decodeURIComponent(placeMatch[1].replace(/\+/g, ' ')).split(',')[0].trim();
  const qMatch = u.match(/[?&](?:q|query)=([^&]+)/);
  if (qMatch) return decodeURIComponent(qMatch[1].replace(/\+/g, ' ')).split(',')[0].trim();
  return null;
}
```

Only for short links (`maps.app.goo.gl`, `goo.gl/maps`) that don't carry
the name in the URL, follow the redirect to get the long-form URL — but
still never read the destination page's body, only its final URL after
redirects.

For everything else (articles, most sites), fetch normally and read
`og:title` / `twitter:title` / `<title>`, in that order.

**Known, unfixable limitation:** Instagram, XHS/小红书, TikTok and similar
apps render their real content client-side via JS — the server-rendered
HTML only ever contains a generic app-shell title ("Instagram", "小红书"),
never the actual post/place name. There is no free workaround without
their paid developer APIs. Detect this (a small list of known generic
titles) and return a clean "couldn't find a name, type it in" error
instead of silently filling in the useless generic string.

**Universal safety net — apply this regardless of which path above was
taken:** never let a raw URL, or garbage scraped from a blocked/captcha
page, reach the `name` field or the status text.

```js
function cleanName(raw) {
  if (!raw) return null;
  let name = decodeHtmlEntities(raw).trim();
  // URL-encoded slugs (no spaces, has a '+') need de-encoding, but a genuine
  // name containing a literal '+' (rare) usually already has real spaces —
  // only treat it as encoded if there are NO spaces at all.
  if (!/\s/.test(name) && /\+/.test(name)) name = name.replace(/\+/g, ' ');
  name = name.replace(/\s+/g, ' ').trim();
  if (!name) return null;
  if (/^https?:\/\//i.test(name) || /^www\./i.test(name)) return null; // never a raw link
  if (name.length > 70) name = name.slice(0, 70).trim() + '…';
  return name;
}
```

The status/name field CSS must also independently guard against overflow
(`overflow-wrap:anywhere; word-break:break-word;`) as defense in depth —
never let long text break out of its card regardless of what produced it.

7. OPTION CARD — INTERACTION MODEL
--------------------------------------

**Tap-to-vote, not tap-to-expand:** tapping anywhere on an option row
casts a vote for it. Only a small dedicated chevron button (own bounded
tap target, `stopPropagation` on click) expands/collapses the detail
area below (notes, links, voter list). This split matters — a single
undifferentiated tap target that sometimes votes and sometimes expands,
depending on exactly where you tap, causes constant mis-taps.

**Vote indicator is a small pill, not a big button:** "Vote" (outline) /
"✓ Voted" (filled) — keep it compact (roughly 38×24px, ~9px bold
uppercase text). It's a status indicator riding along on a row that
already votes on tap anywhere; sizing it like a primary CTA is visually
loud for what little additional information it conveys.

**Swipe-to-delete, tuned for a comfortable one-thumb swipe:** dragging an
option (or a home-page recent-poll row) left reveals a delete affordance;
dragging far enough auto-commits the delete. The auto-commit distance
must be a *short* swipe, not most of the screen width:

```js
FAR = onAutoDelete ? -Math.max(108, wrapWidth * 0.36) : -Infinity;
```
(108px floor / 36% of row width — a `200px`/`62%` version tested worse:
users reported needing their other hand to reach it.) A shorter drag that
doesn't reach `FAR` snaps open to a small reveal state with an explicit
delete button, so an incomplete swipe is still recoverable, not lost.

**Only one action icon in the expanded row: edit (pencil).** No separate
trash icon — swipe-to-delete already covers deletion, and a second
delete-looking icon right next to an edit icon just adds mis-tap risk for
no new capability. If you remove a delete icon that used to sit to the
right of the edit icon, leave an inert same-sized invisible spacer in its
place rather than letting the edit icon slide over to fill the gap —
keeping its exact position stable avoids a muscle-memory mis-tap for
anyone used to the old layout.

**Delete confirmations don't say "you can undo right after."** A
confirmation step exists specifically so an accidental tap doesn't cost
something — telling the user it's reversible undercuts that and
encourages carelessness. (A real undo still exists, per §12 — it just
isn't advertised inside the warning itself.)

**Every modal (including this one) opens centered on screen**
(`align-items:center` on the backdrop, full border-radius, not a
bottom-anchored sheet) so its action buttons land in comfortable thumb
reach regardless of content height, instead of pinned to the very bottom
edge of the viewport.

8. ICON / BRANDING
---------------------

App icon: a colorful diagonal gradient (violet → magenta/pink → gold)
rounded-square background, with a white ballot-box + checkmark glyph
(a box with a ballot card sticking out of the slot, checkmark on the
card) — not a flat single-color icon. A few small confetti-dot accents
in complementary bright colors are a nice touch at large sizes but should
stay legible at small (192px and below) sizes too. The small in-app brand
mark (topbar logo) uses the same gradient direction for consistency.

9. SHARE TARGET — "Share to YouVote" from other apps (Android/Chrome)
-------------------------------------------------------------------------

Register as a native Android share-sheet destination so a link seen in
another app (e.g. WhatsApp) can be shared straight in instead of
copy-pasted. `manifest.json`:

```json
"share_target": {
  "action": "/",
  "method": "GET",
  "params": { "title": "shared_title", "text": "shared_text", "url": "shared_url" }
}
```
GET-based, so it needs zero service-worker changes — it's just a normal
navigation to `/?shared_url=...` that client JS reads on load.

Apps commonly put the link in `text` rather than a dedicated `url` field
(WhatsApp does this), sometimes with extra words around it — scan all
three params for the first URL-looking substring:

```js
function extractSharedLink(sharedUrl, sharedText, sharedTitle){
  const urlRe = /https?:\/\/[^\s]+/i;
  const source = [sharedUrl, sharedText, sharedTitle].find(s => s && urlRe.test(s));
  if (!source) return null;
  return source.match(urlRe)[0].replace(/[)\]>,.!?"']+$/, '');
}
```

Routing once a shared link is detected (and immediately strip the
`shared_*` params from the URL via `history.replaceState` so a refresh
doesn't replay the same share):
- **Zero recent polls** on this device → friendly "start a poll first"
  screen.
- **Exactly one** recent poll → land straight in it, add-option form
  pre-expanded, link field pre-filled, and auto-trigger the resolve call
  immediately (don't make the user tap Search themselves) so the name is
  already found by the time they look at the screen. Show a one-time
  toast explaining what just happened.
- **More than one** → a lightweight picker listing recent polls by title;
  tapping one lands in it the same way as the single-poll case.

**Known platform limitation:** iOS Safari doesn't support the Web Share
Target API — this feature is Android/Chrome only. On iPhone, sharing a
link still requires opening YouVote and pasting manually. Don't build
around trying to fake this on iOS; there's no reliable way to.

10. SERVICE WORKER — network-first, not cache-first
--------------------------------------------------------

Same reasoning as any actively-iterated PWA: a cache-first worker keeps
serving a stale version forever once a device has loaded it once, even
after a real fix ships, because the fetch handler never even attempts a
network request when a cached copy exists. Always try the network first;
fall back to cache only on genuine fetch failure (offline):

```js
self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  event.respondWith(
    fetch(event.request).then((res) => {
      const copy = res.clone();
      caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy)).catch(() => {});
      return res;
    }).catch(() => caches.match(event.request))
  );
});
```
Bump `CACHE_NAME`'s version string on any deploy meant to force-evict old
entries.

11. LOCAL UNDO/REDO (per-device, per-visit)
-----------------------------------------------

Every mutating action this device takes in this poll visit (vote, add
option, delete option, edit option) pushes `{label, undo, redo}` onto an
in-memory stack — never synced, resets on reopening the poll. This is
what backs the small undo/redo buttons near the option list. Separately,
there's a **permanent bottom-right floating pill** (icon + label combined
in one tappable element, not a separate icon-only button plus a
hover-only tooltip — a hover tooltip is unusable on a touchscreen) that
surfaces the single most recent destructive action (an option delete or
poll delete) with a direct restore action, shown/hidden via an
`active` class rather than always rendered at low opacity.

PROMPT ENDS HERE
